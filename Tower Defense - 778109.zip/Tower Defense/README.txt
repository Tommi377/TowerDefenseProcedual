HOW TO RUN THIS PROGRAM.
3 WAYS:

1)
Go to the Game folder and run the jar

2)
If you have SBT installed you can run this in the Project folder
> sbt run
and it will compile and run the program

3)
If you have eclipse you import the project and run Main.scala


HOW TO TEST THIS PROGRAM

If you have SBT installed you can run this in the Project folder
> sbt test
and it will run the tests


CAN I CHANGE THE CONFIG FILES?

Yes, you are encouraged to change and add anything to the config files!