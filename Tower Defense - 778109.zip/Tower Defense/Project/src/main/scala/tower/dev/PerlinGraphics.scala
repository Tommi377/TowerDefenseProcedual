package tower

import scala.swing._
import scala.swing.event._
import scala.util.Random

class PerlinGraphics(width: Int, height: Int) extends Component {
  val s = 512
  var o = 5
  var b = 0.2
  val perlin = new Perlin(s, s, o, b)
  perlin.calculatePerlin(Random.nextInt)
  
  override def paintComponent(g: Graphics2D) = {
    
    for (x <- 0 until s; y <- 0 until s) {
      val c = perlin(x)(y) match {
        case v if (v < 0.15) => new Color(0, 0, 255)
        case v if (v < 0.3) => new Color(0, 127, 255)
        case v if (v < 0.6) => new Color(0, 180, 0)
        case v if (v < 0.8) => new Color(0, 127, 0)
        case _              => new Color(127, 127, 127)
      }
      g.setColor(c)
      g.fillRect(x, y, 1, 1)
    }
  }
  
  
  
  reactions += {
    case MouseMoved(c, point, mods) => //println("moved: " + point + " " + mods)
    case MouseClicked(c, point, mods, clicks, triggersPopup) => println("clicked: " + point + " " + mods); perlin.calculatePerlin(Random.nextInt); repaint()
    case MouseWheelMoved(c, point, mods, rotation) => println("wheel: " + point + " " + mods + " " + rotation)
    case KeyPressed(c, key, mods, loc) => {
      println("key: " + key + " " + mods)
      key.toString match {
        case "S" => o = (o + 1).min(10)
        case "W" => o = (o - 1).max(1)
        case "D" => b = (b + 0.05)
        case "A" => b = (b - 0.05).max(0)
        case "Space" => perlin.calculatePerlin(Random.nextInt);
        case _ => Unit
      }
      
      println(o, b)
      perlin.calculatePerlin(Random.nextInt)
      repaint()
    }
  }
  
  listenTo(mouse.clicks, mouse.moves, mouse.wheel, keys)
  focusable = true
}